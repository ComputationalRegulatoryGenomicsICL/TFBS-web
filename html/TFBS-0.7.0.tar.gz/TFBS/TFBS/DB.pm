# This package should hold interface and common database manipulation
# methods, if we decide there are any

package TFBS::DB;

use vars qw(@ISA);
use strict;
use Bio::Root::Root;
use TFBS::Matrix;
@ISA = qw(Bio::Root::Root);

sub new  {

}

sub get_MatrixSet  {

}


sub get_Matrix_by_ID {

}
    # not finished (apparently)
